package com.cogent.week1Assessment;

public class EmployeeManagementTester {

	public static void main(String[] args) {
		EmployeeManagement employee_mgmt = new EmployeeManagement("John", 20, "Finance");
		employee_mgmt.deleteRecord("John", 46, "Accounting");
		EmployeeManagement.addRecord("Sam", 22, "Admin");
		

	}

}
