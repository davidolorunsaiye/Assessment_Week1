package com.cogent.week1Assessment;

public class SimpleInterestTester {

	public static void main(String[] args) {
		SimpleInterest SI = new SimpleInterest();
		SI.calculateInterest(100000, 4.5, 30);

	}

}
