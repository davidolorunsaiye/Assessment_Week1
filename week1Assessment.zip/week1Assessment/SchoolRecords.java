package com.cogent.week1Assessment;

public class SchoolRecords {
	String schoolName;
	int schoolID;
	String schoolAddress;
	
	void addAll(String schoolName, int schoolID, String schoolAddress) {
		
		System.out.println("The school name is " + schoolName + ", its ID is " + schoolID + ", and it's address is " + schoolAddress);
	}

}
