package com.cogent.week1Assessment;

public class SimpleInterest {
	
	static int principle;
	static double rate;
	static int time;
	double si;
	double total;
	void calculateInterest(int principle, double rate, int time) {
		
		SimpleInterest.principle = principle;
		SimpleInterest.rate = rate;
		SimpleInterest.time = time;
		rate = rate / 100;
		
		si = (principle * rate * time) / 100;
		System.out.println("The simple interest is " + si);
		
		total = principle + si;
		System.out.println("The total amount to be paid back is $" + total);
	}
	

}