package com.cogent.week1Assessment;

public class EmployeeManagement {
	
	
	static void addRecord(String name, int age, String dept) {
		
		if(name != null && age > 0 && dept != null) {
			System.out.println("Record successfully added");
		}
		else {
			System.out.println("Add a record");
		}
		
	}
	public EmployeeManagement(String name, int age, String dept) { // display record
		System.out.println("Name: " + name + " Age: " + age + " dept: " + dept);
		
	}
	void deleteRecord(String name, int age, String dept) {
		
		if(name != null || age > 0 || dept != null) {
			name = "";
			age = 0;
			dept = "";
			System.out.println("Name: " + name + " Age: " + age + " dept: " + dept);
			System.out.println("Record successfully deleted");
		}
		else {
			System.out.println("Retry delete process");
		}
	}

}
