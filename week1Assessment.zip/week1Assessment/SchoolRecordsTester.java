package com.cogent.week1Assessment;

public class SchoolRecordsTester {

	public static void main(String[] args) {
		
		SchoolRecords schoolRecords = new SchoolRecords();
		schoolRecords.addAll("School 1", 1, "USA");

	}

}
